from CGSystem import CGSystem

sys = CGSystem()
sys.run()
